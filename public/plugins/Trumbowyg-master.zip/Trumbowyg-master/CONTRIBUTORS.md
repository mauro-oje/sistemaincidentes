# Contributors

Trumbowyg is the result of many people who made translations or the code better.

Special thanks to [Adrien Gervaix](https://dribbble.com/adriengervaix) for the Trumbowyg v2 icon set.

- Alex-D
- lizardK
- Ra100
- VeeeneX
- Danny Hiemstra
- Nicolás Moncada
- Civil
- Jan Svoboda
- g2010a
- foo9
- matopeter
- Manfred62
- Merianos Nikos
- Nikola Trifunovic
- jake johns
- Vlad Radulescu
- Rezha Julio
- Tim
- Vietworm
- Vinzgore
- Wisse Jelgersma
- abomokhahmed
- akai
- basteyy
- brentanalexander
- dev.hibiki
- kingdido999
- munzur
- teppokoivula
- udidoron
- Игорь
- Adam Balogh
- Олег Ильин
- Andreas Kohn
- Andrey Kogut
- Antoine Leblanc
- Artur
- Burak Erdem
- Christian
- Delvallée
- John Pozy
- JoongSeob Vito Kim
- MIRK0
- Mike Goodfellow
- Mike Richmond
- Moisés Márquez
- Nathan Rosquist
- Oleg Berman
- Paweł Abramowicz
- Peter Dave Hello
- Ramiro Varandas Jr